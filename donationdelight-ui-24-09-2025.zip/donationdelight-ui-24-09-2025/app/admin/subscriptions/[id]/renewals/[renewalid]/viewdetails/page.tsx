"use client";
import React, { useState } from "react";

// Mock data for demonstration
const renewalData = {
  donationFormId: "9",
  donationDate: "September 1, 2025",
  totalDonation: 250.0,
  donationFormTitle: "Fundraising Campaign",
  campaign: "Bright Futures",
  donationLevel: "Custom",
  anonymous: false,
  donorId: "266",
  donorName: "Jessica Johnson",
  donorEmail: "jessicajohnson917@example.com",
  donorSince: "June 4, 2025",
  billingAddress: {
    country: "United States",
    address1: "",
    address2: "",
    city: "",
    state: "",
    zip: ""
  },
  status: "Renewal",
  time: "02:21",
  feeAmount: 0.0,
  gateway: "Test Donation",
  key: "b409c6d591702f11a9dc1302f803fff",
  ip: "173.69.1.181",
  transactionId: "txn_684066f1b8ea_5809",
  parentPayment: "420",
  customFields: {},
  tributes: "No Tributes"
};

export default function RenewalViewDetailsPage() {
  const [donor, setDonor] = useState(renewalData.donorName);
  return (
    <div style={{ width: '100%', minHeight: '100vh', background: '#f8fff8', padding: '32px 0' }}>
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 32px' }}>
        <h2 style={{ marginBottom: 24, display: 'flex', alignItems: 'center', fontWeight: 700, color: '#1b5e20', fontSize: 26 }}>
          <span style={{ color: '#43a047', fontSize: 26, marginRight: 10 }}>💚</span>
          Donation {renewalData.parentPayment}
          <span style={{ background: '#fffde7', color: '#fbc02d', borderRadius: 6, padding: '2px 10px', marginLeft: 12, fontWeight: 600, fontSize: 15 }}>Test Donation</span>
        </h2>
        <div style={{ display: 'flex', gap: 32 }}>
          <div style={{ flex: 2 }}>
            <div style={{ background: '#fff', borderRadius: 12, boxShadow: '0 2px 12px #e0f2f1', padding: 32, marginBottom: 32 }}>
              <h3 style={{ color: '#388e3c', fontWeight: 700, marginBottom: 18 }}>Donation Information</h3>
              <div style={{ display: 'flex', gap: 32, marginBottom: 18 }}>
                <div style={{ flex: 1 }}>
                  <div><b>Donation Form ID:</b> {renewalData.donationFormId}</div>
                  <div><b>Donation Form Title:</b> {renewalData.donationFormTitle}</div>
                  <div><b>Campaign:</b> {renewalData.campaign}</div>
                </div>
                <div style={{ flex: 1 }}>
                  <div><b>Donation Date:</b> {renewalData.donationDate}</div>
                  <div><b>Donation Level:</b> {renewalData.donationLevel}</div>
                  <div><b>Total Donation:</b> $ {renewalData.totalDonation.toFixed(2)}</div>
                  <div><b>Anonymous Donation:</b> {renewalData.anonymous ? "Yes" : "No"}</div>
                </div>
              </div>
            </div>
            <div style={{ background: '#fff', borderRadius: 12, boxShadow: '0 2px 12px #e0f2f1', padding: 32, marginBottom: 32 }}>
              <h3 style={{ color: '#388e3c', fontWeight: 700, marginBottom: 18 }}>Donor Details</h3>
              <div style={{ display: 'flex', gap: 32, marginBottom: 18 }}>
                <div style={{ flex: 1 }}>
                  <div><b>Donor ID:</b> <a href="#" style={{ color: '#1976d2' }}>{renewalData.donorId}</a></div>
                  <div><b>Donor Since:</b> {renewalData.donorSince}</div>
                </div>
                <div style={{ flex: 1 }}>
                  <div><b>Donor Name:</b> {renewalData.donorName}</div>
                  <div><b>Donor Email:</b> {renewalData.donorEmail}</div>
                  <div><b>Change Donor:</b> <input value={donor} onChange={e => setDonor(e.target.value)} style={{ width: 220, borderRadius: 6, border: '1px solid #b2dfdb', padding: '4px 8px' }} /></div>
                </div>
              </div>
            </div>
            <div style={{ background: '#fff', borderRadius: 12, boxShadow: '0 2px 12px #e0f2f1', padding: 32, marginBottom: 32 }}>
              <h3 style={{ color: '#388e3c', fontWeight: 700, marginBottom: 18 }}>Billing Address</h3>
              <div style={{ display: 'flex', gap: 32, marginBottom: 18 }}>
                <div style={{ flex: 1 }}>
                  <div><b>Country:</b> {renewalData.billingAddress.country}</div>
                  <div><b>Address 1:</b> {renewalData.billingAddress.address1}</div>
                  <div><b>Address 2:</b> {renewalData.billingAddress.address2}</div>
                </div>
                <div style={{ flex: 1 }}>
                  <div><b>City:</b> {renewalData.billingAddress.city}</div>
                  <div><b>State / Province / County:</b> {renewalData.billingAddress.state}</div>
                  <div><b>Zip / Postal Code:</b> {renewalData.billingAddress.zip}</div>
                </div>
              </div>
            </div>
            <div style={{ background: '#fff', borderRadius: 12, boxShadow: '0 2px 12px #e0f2f1', padding: 32, marginBottom: 32 }}>
              <h3 style={{ color: '#388e3c', fontWeight: 700, marginBottom: 18 }}>Custom Fields</h3>
              <div>No custom fields.</div>
            </div>
            <div style={{ background: '#fff', borderRadius: 12, boxShadow: '0 2px 12px #e0f2f1', padding: 32, marginBottom: 32 }}>
              <h3 style={{ color: '#388e3c', fontWeight: 700, marginBottom: 18 }}>Tributes</h3>
              <div>{renewalData.tributes}</div>
            </div>
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ background: '#fff', borderRadius: 12, boxShadow: '0 2px 12px #e0f2f1', padding: 32, marginBottom: 32 }}>
              <h3 style={{ color: '#388e3c', fontWeight: 700, marginBottom: 18 }}>Subscription Information</h3>
              <div><b>Parent Payment:</b> <a href="#" style={{ color: '#1976d2' }}>{renewalData.parentPayment}</a></div>
            </div>
            <div style={{ background: '#fff', borderRadius: 12, boxShadow: '0 2px 12px #e0f2f1', padding: 32, marginBottom: 32 }}>
              <h3 style={{ color: '#388e3c', fontWeight: 700, marginBottom: 18 }}>Update Donation</h3>
              <div><b>Status:</b> {renewalData.status}</div>
              <div><b>Date:</b> {renewalData.donationDate}</div>
              <div><b>Time:</b> {renewalData.time}</div>
              <div><b>Total Donation:</b> $ {renewalData.totalDonation.toFixed(2)}</div>
              <div><b>Fee Amount:</b> $ {renewalData.feeAmount.toFixed(2)}</div>
              <div style={{ marginTop: 12, color: '#1976d2', fontSize: 14 }}>
                <span>🔄 This is a renewal payment for the donation form: "{renewalData.donationFormTitle}"</span>
              </div>
              <div style={{ display: 'flex', gap: 12, marginTop: 18 }}>
                <button style={{ background: '#1976d2', color: '#fff', border: 'none', borderRadius: 6, padding: '8px 24px', fontWeight: 600, fontSize: 16 }}>Resend Receipt</button>
                <button style={{ background: '#388e3c', color: '#fff', border: 'none', borderRadius: 6, padding: '8px 24px', fontWeight: 600, fontSize: 16 }}>Save Donation</button>
              </div>
            </div>
            <div style={{ background: '#fff', borderRadius: 12, boxShadow: '0 2px 12px #e0f2f1', padding: 32, marginBottom: 32 }}>
              <h3 style={{ color: '#388e3c', fontWeight: 700, marginBottom: 18 }}>Donation Meta</h3>
              <div><b>Gateway:</b> {renewalData.gateway}</div>
              <div><b>Key:</b> {renewalData.key}</div>
              <div><b>IP:</b> {renewalData.ip}</div>
              <div><b>Transaction ID:</b> {renewalData.transactionId}</div>
              <div style={{ marginTop: 12 }}>
                <a href="#" style={{ color: '#1976d2' }}>View all donations for this donor &rarr;</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
