export default function donation_tributes() {
  return <div>Tributes</div>;
}