"use client";
import { useState } from "react";
import { Dialog } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import Link from "next/link";
export default function SubscriptionDetailsPage() {
  // Example data (replace with real data as needed)
  const subscription = {
    amount: 147,
    interval: "month",
    status: "Active",
    test: true,
    totalContribution: 588,
    paymentsCompleted: 4,
    paymentsTotal: "∞",
    campaign: "Bright Futures",
    nextPayment: "7th September 2025, 7:52 pm",
    unlimited: true,
    donor: {
      name: "Susan Clark",
      email: "susan.clark198@mail.com",
    },
    gateway: "Test Donation",
    projectedAnnualRevenue: 1176,
    projectedPercent: 50,
    startDate: "7th May, 2025",
    endDate: "Ongoing",
    donationForm: "Donation Form",
    renewal: 147,
    notes: [],
  };

  const [tab, setTab] = useState("Overview");
  const [showRenewalModal, setShowRenewalModal] = useState(false);
  const [renewalAmount, setRenewalAmount] = useState(subscription.amount);
  const [renewalDate, setRenewalDate] = useState("");
  const [updateRenewalDate, setUpdateRenewalDate] = useState(false);
  const [transactionId, setTransactionId] = useState("");

  // Example donations data
  const donations = [
    { id: 480, type: "Renewal", campaign: "Bright Futures", date: "08/07/2025 at 7:52 pm", status: "Completed", amount: 147 },
    { id: 479, type: "Renewal", campaign: "Bright Futures", date: "07/07/2025 at 7:52 pm", status: "Completed", amount: 147 },
    { id: 478, type: "Renewal", campaign: "Bright Futures", date: "06/07/2025 at 7:52 pm", status: "Completed", amount: 147 },
    { id: 477, type: "Initial donation", campaign: "Bright Futures", date: "05/07/2025 at 7:52 pm", status: "Completed", amount: 147 },
  ];

  return (
    <div className="p-8 bg-gray-50 min-h-screen">
      <div className="mb-6 flex items-center gap-4">
        <span className="text-3xl font-bold">${subscription.amount.toFixed(2)}</span>
        <span className="text-lg text-gray-600">every {subscription.interval}</span>
        <span className={`px-3 py-1 rounded text-xs font-semibold ${subscription.status === "Active" ? "bg-green-100 text-green-700" : "bg-gray-200 text-gray-700"}`}>{subscription.status}</span>
        {subscription.test && <span className="px-3 py-1 rounded text-xs font-semibold bg-orange-100 text-orange-700">Test Subscription</span>}
        <button className="ml-auto px-4 py-2 border rounded bg-white">Sync subscription</button>
        <button className="px-4 py-2 border rounded bg-white">Save changes</button>
        <Link
          href="/admin/subscriptions/34/editview"
          className="px-4 py-2 border rounded bg-blue-600 text-white font-semibold ml-2 hover:bg-blue-700 transition"
        >
          Go to Edit Subscription
        </Link>
      </div>
      <div className="flex gap-8 border-b mb-8">
        {["Overview", "Donations", "Information"].map((t) => (
          <button
            key={t}
            className={`px-6 py-3 -mb-px font-medium border-b-2 ${tab === t ? "border-green-500 text-green-700 bg-white" : "border-transparent text-gray-700 bg-gray-100"}`}
            onClick={() => setTab(t)}
          >
            {t}
          </button>
        ))}
      </div>
      {tab === "Overview" && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
            <div className="bg-white rounded shadow p-6 flex flex-col gap-6">
              <div className="grid grid-cols-2 gap-6 mb-6">
                <div>
                  <div className="text-xs text-gray-500 mb-1">Total contribution so far</div>
                  <div className="text-2xl font-bold">${subscription.totalContribution.toFixed(2)}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-500 mb-1">Payments completed</div>
                  <div className="text-2xl font-bold">{subscription.paymentsCompleted} / {subscription.paymentsTotal}</div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-6 mb-6">
                <div className="bg-gray-50 rounded p-4">
                  <div className="text-xs text-gray-500 mb-1">Campaign name</div>
                  <div className="font-semibold">{subscription.campaign}</div>
                </div>
                <div className="bg-gray-50 rounded p-4">
                  <div className="text-xs text-gray-500 mb-1">Next payment</div>
                  <div className="font-semibold">{subscription.nextPayment}</div>
                  {subscription.unlimited && <span className="mt-2 inline-block px-2 py-0.5 rounded text-xs bg-green-100 text-green-700">Unlimited</span>}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-6 mb-6">
                <div className="bg-gray-50 rounded p-4">
                  <div className="text-xs text-gray-500 mb-1">Associated donor</div>
                  <div className="font-semibold text-blue-700">{subscription.donor.name}</div>
                  <div className="text-xs text-gray-500">{subscription.donor.email}</div>
                </div>
                <div className="bg-gray-50 rounded p-4">
                  <div className="text-xs text-gray-500 mb-1">Gateway</div>
                  <div className="font-semibold">{subscription.gateway}</div>
                </div>
              </div>
            </div>
            <div className="bg-white rounded shadow p-6 flex flex-col gap-6">
              <div className="font-semibold mb-2">Projected Annual Revenue</div>
              <div className="flex items-center gap-6">
                <div className="relative w-32 h-32 flex items-center justify-center">
                  <svg viewBox="0 0 100 100" className="absolute w-full h-full">
                    <circle cx="50" cy="50" r="45" stroke="#e5e7eb" strokeWidth="10" fill="none" />
                    <circle cx="50" cy="50" r="45" stroke="#22c55e" strokeWidth="10" fill="none" strokeDasharray="282.74" strokeDashoffset="141.37" />
                  </svg>
                  <div className="absolute w-full h-full flex items-center justify-center">
                    <span className="text-2xl font-bold">{subscription.projectedPercent}%</span>
                  </div>
                </div>
                <div>
                  <div className="text-xs text-gray-500 mb-1">Estimated contribution</div>
                  <div className="text-green-600 font-bold text-xl">${subscription.projectedAnnualRevenue.toFixed(2)}</div>
                </div>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div className="bg-white rounded shadow p-6">
              <div className="font-semibold mb-2">Private Note</div>
              <div className="text-xs text-gray-500 mb-4">This note will be seen by only admins</div>
              <div className="min-h-[60px] flex items-center justify-center text-gray-400">
                No notes yet
              </div>
              <button className="mt-4 px-4 py-2 border rounded bg-gray-50">Add note</button>
            </div>
            <div className="bg-white rounded shadow p-6 col-span-2">
              <div className="font-semibold mb-2">Summary</div>
              <div className="text-xs text-gray-500 mb-4">Information about the initial recurring donation</div>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex flex-col gap-2">
                  <div className="flex justify-between"><span>Start date</span><span>{subscription.startDate}</span></div>
                  <div className="flex justify-between"><span>End date</span><span>{subscription.endDate}</span></div>
                  <div className="flex justify-between"><span>Donation form</span><span className="text-blue-700 underline cursor-pointer">{subscription.donationForm}</span></div>
                  <div className="flex justify-between"><span>Renewal</span><span className="text-green-600 font-bold">${subscription.renewal.toFixed(2)}</span></div>
                </div>
              </div>
            </div>
          </div>
        </>
      )}
      {tab === "Donations" && (
        <div className="bg-white rounded shadow p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="font-semibold text-lg">Donations</div>
            <Button variant="outline" onClick={() => setShowRenewalModal(true)}>Add renewal</Button>
          </div>
          <div className="text-xs text-gray-500 mb-4">Show all recurring donations under this subscription.</div>
          <table className="w-full text-left border-separate border-spacing-0 rounded-lg overflow-hidden shadow-sm">
            <thead>
              <tr className="bg-green-50">
                <th className="py-3 px-4 font-semibold text-green-700 border-b border-green-100">ID</th>
                <th className="py-3 px-4 font-semibold text-green-700 border-b border-green-100">Type</th>
                <th className="py-3 px-4 font-semibold text-green-700 border-b border-green-100">Campaign</th>
                <th className="py-3 px-4 font-semibold text-green-700 border-b border-green-100">Date</th>
                <th className="py-3 px-4 font-semibold text-green-700 border-b border-green-100">Status</th>
                <th className="py-3 px-4 font-semibold text-green-700 border-b border-green-100">Amount</th>
              </tr>
            </thead>
            <tbody>
              {donations.map((d, idx) => (
                <tr
                  key={d.id}
                  className={
                    `transition-colors ${idx % 2 === 0 ? 'bg-white' : 'bg-gray-50'} hover:bg-green-50`
                  }
                >
                  <td className="py-3 px-4">
                    <span className="inline-block bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs font-semibold">#{d.id}</span>
                  </td>
                  <td className="py-3 px-4">
                    <span className="border px-3 py-1 rounded-full text-xs bg-green-100 text-green-700 font-semibold">{d.type}</span>
                  </td>
                  <td className="py-3 px-4">
                    <span className="text-blue-700 underline cursor-pointer font-medium">{d.campaign}</span>
                  </td>
                  <td className="py-3 px-4 text-gray-600">{d.date}</td>
                  <td className="py-3 px-4">
                    <span className="bg-green-100 text-green-700 px-2 py-1 rounded text-xs font-semibold">{d.status}</span>
                  </td>
                  <td className="py-3 px-4 font-bold text-green-700">${d.amount.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="mt-4 text-xs text-gray-500">{donations.length} RESULTS</div>

          {/* Renewal Modal */}
          {showRenewalModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black-100 bg-opacity-30">
              <div className="bg-white rounded-lg shadow-lg w-full max-w-md p-8 relative">
                <button
                  className="absolute top-4 right-4 text-gray-400 hover:text-gray-700 text-xl"
                  onClick={() => setShowRenewalModal(false)}
                  aria-label="Close"
                >
                  &times;
                </button> 
                <h2 className="text-xl font-bold mb-6">Renewal donation</h2>
                <form className="flex flex-col gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Amount</label>
                    <input
                      type="number"
                      className="w-full border rounded px-3 py-2"
                      value={renewalAmount}
                      onChange={e => setRenewalAmount(Number(e.target.value))}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Date</label>
                    <input
                      type="date"
                      className="w-full border rounded px-3 py-2"
                      value={renewalDate}
                      onChange={e => setRenewalDate(e.target.value)}
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={updateRenewalDate}
                      onChange={e => setUpdateRenewalDate(e.target.checked)}
                    />
                    <label className="text-sm">Update renewal date</label>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Transaction ID <span className="text-gray-400">(optional)</span></label>
                    <input
                      type="text"
                      className="w-full border rounded px-3 py-2"
                      value={transactionId}
                      onChange={e => setTransactionId(e.target.value)}
                    />
                  </div>
                  <Button className="w-full mt-4 bg-blue-700 text-white hover:bg-blue-800">Add renewal</Button>
                  <div className="border rounded bg-blue-50 text-blue-700 p-3 text-sm flex items-center gap-2 mt-2">
                    <svg width="18" height="18" fill="none" viewBox="0 0 24 24"><rect width="24" height="24" rx="12" fill="#E3F2FD"/><path d="M12 8v4l3 3" stroke="#1976d2" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
                    <span>Please note that this will not charge the donor nor create the renewal at the gateway.</span>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}
      {tab === "Information" && (
        <div className="bg-white rounded shadow p-6 flex flex-col items-center justify-center min-h-[200px]">
          <div className="text-4xl text-gray-400 mb-2">&#128196;</div>
          <div className="text-gray-500">No records found</div>
        </div>
      )}
      <div className="text-xs text-gray-500 mt-8">If you like DonationDelight please leave us a ★★★★★ rating. It takes a minute and helps a lot. Thanks in advance!</div>
    </div>
  );
}
