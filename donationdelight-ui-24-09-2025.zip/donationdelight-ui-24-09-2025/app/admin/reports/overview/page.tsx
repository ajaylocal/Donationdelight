
'use client'
import React, { useState } from "react";
import { DateRange } from "react-date-range";
import 'react-date-range/dist/styles.css';
import 'react-date-range/dist/theme/default.css';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area
} from "recharts"
// Mock data for charts and tables
// const mockRevenueData = [
//   { date: "Sep 17", value: 850 },
//   { date: "Sep 18", value: 85 },
//   { date: "Sep 19", value: 100 },
//   { date: "Sep 20", value: 50 },
//   { date: "Sep 21", value: 0 },
//   { date: "Sep 22", value: 0 },
//   { date: "Sep 23", value: 0 },
//   { date: "Sep 24", value: 0 },
// ];
const mockRevenueData = [
  { date: "Sep 17", value: 850, donors: 5 },
  { date: "Sep 18", value: 100, donors: 2 },
  { date: "Sep 19", value: 50, donors: 1 },
  { date: "Sep 20", value: 0, donors: 0 },
  { date: "Sep 21", value: 0, donors: 0 },
  { date: "Sep 22", value: 0, donors: 0 },
  { date: "Sep 23", value: 0, donors: 0 },
  { date: "Sep 24", value: 0, donors: 0 },
]
type Range = {
  startDate: Date;
  endDate: Date;
  key: string;
};

type RangeKeyDict = {
  [key: string]: Range;
};
// Custom tooltip to match screenshot style
const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white p-2 border rounded shadow-sm text-sm">
        <p className="font-semibold">${payload[0].value}</p>
        <p>{payload[0].payload.donors} Donors</p>
        <p>{label}</p>
      </div>
    )
  }
  return null
}
const summary = {
  totalRevenue: 935,
  avgDonation: 116.88,
  totalDonors: 8,
  totalRefunds: 0,
};

const breakdown = [
  { date: "September 16, 2025", donors: 5, donations: 825, refunds: 0, net: 825 },
  { date: "September 17, 2025", donors: 6, donations: 85, refunds: 0, net: 85 },
  { date: "September 18, 2025", donors: 2, donations: 100, refunds: 0, net: 100 },
  { date: "September 19, 2025", donors: 0, donations: 50, refunds: 0, net: 50 },
  { date: "September 20, 2025", donors: 0, donations: 0, refunds: 0, net: 0 },
];

const paymentMethods = [
  { label: "Test Donation", value: 935, percent: 100 },
  { label: "Manual Donation", value: 0, percent: 0 },
  { label: "Stripe: Credit Card", value: 0, percent: 0 },
  { label: "stripe - checkout", value: 0, percent: 0 },
  { label: "stripe - SEPA Direct Debit", value: 0, percent: 0 },
];

const paymentStatuses = [
  { label: "Completed", value: 8 },
  { label: "Pending", value: 0 },
  { label: "Refunded", value: 0 },
  { label: "Abandoned", value: 0 },
  { label: "Canceled", value: 0 },
  { label: "Failed", value: 0 },
];

const formPerformance = [
  { label: "Climate Action Now!", value: 300, percent: 36 },
  { label: "Fundraising Campaign", value: 150, percent: 17 },
  { label: "Donation Form", value: 100, percent: 11 },
  { label: "Literary Program", value: 100, percent: 11 },
  { label: "Local Business Recovery", value: 50, percent: 6 },
];

const donationActivity = [
  { amount: 75, type: "One-Time Donation", donor: "Melisa Anderson", form: "Donation Form" },
  { amount: 25, type: "One-Time Donation", donor: "Elizabeth Harris", form: "Donation Form" },
  { amount: 100, type: "One-Time Donation", donor: "Richard Lee", form: "Literary Program" },
  { amount: 150, type: "One-Time Donation", donor: "Nancy Moore", form: "Student Meal Fund General Fund" },
  { amount: 25, type: "One-Time Donation", donor: "Amanda Thompson", form: "Local Business Recovery" },
  { amount: 300, type: "One-Time Donation", donor: "William Moore", form: "Climate Action Now!" },
];

const topDonors = [
  { name: "Richard Lee", email: "richard.lee87@sample.org", donations: 1 },
  { name: "Nancy Moore", email: "nancy.moore@sample.org", donations: 1 },
  { name: "Amanda Thompson", email: "amanda.thompson917@sample.org", donations: 1 },
  { name: "Jennifer Jones", email: "jennifer.jones40@test.com", donations: 1 },
];

export default function ReportsPage() {
	const [dateRange, setDateRange] = useState({ from: "09/17/2025", to: "09/24/2025" });
	const [filter, setFilter] = useState("Week");
	const [showDatePicker, setShowDatePicker] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50 p-4 md:p-8">
      <div className="max-w-12xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-green-700">Reports</h1>
            <span className="bg-yellow-100 text-yellow-700 px-2 py-1 rounded text-xs font-semibold ml-2">Admin Panel</span>
          </div>
					<div className="flex items-center gap-2 relative">
						{/* Date Range Input */}
						<div
							className="border rounded px-3 py-2 text-sm bg-white cursor-pointer"
							onClick={() => setShowDatePicker(!showDatePicker)}
						>
							{dateRange.from} - {dateRange.to}
						</div>

						{/* Date Range Picker */}
						{showDatePicker && (
							<div className="absolute top-12 right-0 z-50 bg-white shadow-lg rounded-lg p-2">
								<DateRange
									ranges={[
										{
											startDate: new Date(dateRange.from),
											endDate: new Date(dateRange.to),
											key: "selection",
										},
									]}
									onChange={(ranges: any) => {
										const { startDate, endDate } = ranges.selection;
										setDateRange({
											from: startDate ? startDate.toLocaleDateString("en-GB") : "",
											to: endDate ? endDate.toLocaleDateString("en-GB") : "",
										});
									}}
									moveRangeOnFirstSelection={false}
									editableDateInputs={true}
									months={2}
									direction="horizontal"
								/>
							</div>
						)}

						{/* Filter Buttons */}
						<div className="flex gap-1">
							{["Day", "Week", "Month", "Year", "All Time"].map((f) => (
								<button
									key={f}
									className={`px-3 py-1 rounded text-sm font-semibold border ${
										filter === f
											? "bg-green-100 text-green-700 border-green-300"
											: "bg-white text-gray-700 border-gray-200"
									}`}
									onClick={() => setFilter(f)}
								>
									{f}
								</button>
							))}
						</div>
					</div>
        </div>
       {/* Revenue Chart */}
       <div className="bg-white rounded-lg shadow p-6 mb-4">
			<div className="font-semibold mb-2">Revenue for Period</div>
			<div className="w-full h-96">
			<ResponsiveContainer>
				<LineChart
				data={mockRevenueData}
				margin={{ top: 20, right: 20, left: 0, bottom: 20 }}
				>
				{/* Background grid */}
				<CartesianGrid strokeDasharray="4" vertical={false} stroke="#e0e0e0" />
				{/* X-axis */}
				<XAxis dataKey="date" tick={{ fill: "#888" }} />
				{/* Y-axis */}
				<YAxis tick={{ fill: "#888" }} domain={[0, 1000]} />
				{/* Tooltip */}
				<Tooltip content={<CustomTooltip />} />
				{/* Area under line */}
				<Area
					type="monotone"
					dataKey="value"
					stroke="#43a047"
					fill="#e8f5e9"
					strokeWidth={2}
					activeDot={{ r: 6 }}
				/>
				{/* Line on top */}
				<Line
					type="monotone"
					dataKey="value"
					stroke="#43a047"
					strokeWidth={3}
					dot={{ r: 4 }}
					activeDot={{ r: 8, stroke: "#222", strokeWidth: 2 }}
				/>
				</LineChart>
			</ResponsiveContainer>
			</div>
		</div>
		{/* Summary Cards */}
		<div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-4">
			<div className="bg-white rounded-lg shadow p-6 flex flex-col items-center">
				<div className="text-2xl font-bold text-green-700">${summary.totalRevenue.toLocaleString()}</div>
				<div className="text-xs text-gray-500 mt-2">TOTAL REVENUE</div>
				<div className="text-xs text-red-500 mt-1">▼ 71%</div>
			</div>
			<div className="bg-white rounded-lg shadow p-6 flex flex-col items-center">
				<div className="text-2xl font-bold text-blue-700">${summary.avgDonation.toLocaleString()}</div>
				<div className="text-xs text-gray-500 mt-2">AVERAGE DONATION</div>
				<div className="text-xs text-green-600 mt-1">▲ 8.22%</div>
			</div>
			<div className="bg-white rounded-lg shadow p-6 flex flex-col items-center">
				<div className="text-2xl font-bold text-green-700">{summary.totalDonors}</div>
				<div className="text-xs text-gray-500 mt-2">TOTAL DONORS</div>
				<div className="text-xs text-red-500 mt-1">▼ 73%</div>
			</div>
			<div className="bg-white rounded-lg shadow p-6 flex flex-col items-center">
				<div className="text-2xl font-bold text-gray-700">{summary.totalRefunds}</div>
				<div className="text-xs text-gray-500 mt-2">TOTAL REFUNDS</div>
				<div className="text-xs text-gray-500 mt-1">0%</div>
			</div>
		</div>
		{/* Revenue Breakdown Table */}
		<div className="bg-white rounded-lg shadow p-6 mb-4">
			<div className="font-semibold mb-2">Revenue Breakdown</div>
			<table className="w-full text-left border-separate border-spacing-0 rounded-lg overflow-hidden shadow-sm">
				<thead>
					<tr className="bg-gray-50">
						<th className="py-2 px-4 font-semibold text-gray-700 border-b">Date</th>
						<th className="py-2 px-4 font-semibold text-gray-700 border-b">Donors</th>
						<th className="py-2 px-4 font-semibold text-gray-700 border-b">Donations</th>
						<th className="py-2 px-4 font-semibold text-gray-700 border-b">Refunds</th>
						<th className="py-2 px-4 font-semibold text-gray-700 border-b">Net</th>
					</tr>
				</thead>
				<tbody>
					{breakdown.map((row, idx) => (
						<tr key={row.date} className={idx % 2 === 0 ? "bg-white" : "bg-gray-50"}>
							<td className="py-2 px-4">{row.date}</td>
							<td className="py-2 px-4">{row.donors}</td>
							<td className="py-2 px-4">${row.donations.toLocaleString()}</td>
							<td className="py-2 px-4">{row.refunds}</td>
							<td className="py-2 px-4">${row.net.toLocaleString()}</td>
						</tr>
					))}
				</tbody>
			</table>
			<div className="flex justify-end mt-2">
				<button className="border px-4 py-2 rounded text-sm bg-gray-50 text-gray-700">Export CSV</button>
			</div>
		</div>
        {/* Charts and Lists */}
		<div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-4">
			{/* Payment Methods Donut */}
			<div className="bg-white rounded-lg shadow p-6 flex flex-col items-center">
				<div className="font-semibold mb-2">Payment Methods</div>
				{/* Simple donut chart mockup */}
				<svg width="120" height="120" viewBox="0 0 120 120">
					<circle cx="60" cy="60" r="50" fill="#e8f5e9" />
					<circle cx="60" cy="60" r="50" fill="none" stroke="#43a047" strokeWidth="20" strokeDasharray="314" strokeDashoffset="0" />
				</svg>
				<ul className="mt-4 w-full">
					{paymentMethods.map((pm, idx) => (
						<li key={pm.label} className="flex justify-between text-sm py-1 border-b last:border-b-0">
							<span className={idx === 0 ? "font-semibold text-green-700" : "text-gray-700"}>{pm.label}</span>
							<span>${pm.value} {pm.percent > 0 && <span className="text-xs text-gray-500">({pm.percent}%)</span>}</span>
						</li>
					))}
				</ul>
			</div>
			{/* Payment Statuses Bar */}
			<div className="bg-white rounded-lg shadow p-6 flex flex-col items-center">
				<div className="font-semibold mb-2">Payment Statuses</div>
				<svg width="120" height="120" viewBox="0 0 120 120">
					{paymentStatuses.map((ps, idx) => (
						<rect key={ps.label} x={10 + idx * 18} y={120 - ps.value * 10 - 10} width="14" height={ps.value * 10} fill="#43a047" />
					))}
				</svg>
				<ul className="mt-4 w-full">
					{paymentStatuses.map(ps => (
						<li key={ps.label} className="flex justify-between text-sm py-1 border-b last:border-b-0">
							<span className="text-gray-700">{ps.label}</span>
							<span>{ps.value}</span>
						</li>
					))}
				</ul>
			</div>
			{/* Form Performance Pie */}
			<div className="bg-white rounded-lg shadow p-6 flex flex-col items-center">
				<div className="font-semibold mb-2">Form Performance</div>
							<svg width="120" height="120" viewBox="0 0 120 120">
								{/* Pie chart mockup: colored arcs */}
								{(() => {
									let lastAngle = 0;
									return formPerformance.map((fp, idx) => {
										const startAngle = lastAngle;
										const endAngle = startAngle + fp.percent * 3.6;
										const largeArc = fp.percent > 50 ? 1 : 0;
										const x1 = 60 + 50 * Math.cos(Math.PI * startAngle / 180);
										const y1 = 60 + 50 * Math.sin(Math.PI * startAngle / 180);
										const x2 = 60 + 50 * Math.cos(Math.PI * endAngle / 180);
										const y2 = 60 + 50 * Math.sin(Math.PI * endAngle / 180);
										lastAngle = endAngle;
										return (
											<path key={fp.label} d={`M60,60 L${x1},${y1} A50,50 0 ${largeArc},1 ${x2},${y2} Z`} fill={["#43a047", "#1976d2", "#ffa726", "#78909c", "#8d6e63"][idx % 5]} />
										);
									});
								})()}
							</svg>
				<ul className="mt-4 w-full">
					{formPerformance.map(fp => (
						<li key={fp.label} className="flex justify-between text-sm py-1 border-b last:border-b-0">
							<span className="font-semibold" style={{ color: fp.label === "Climate Action Now!" ? "#43a047" : undefined }}>{fp.label}</span>
							<span>${fp.value} <span className="text-xs text-gray-500">({fp.percent}%)</span></span>
						</li>
					))}
				</ul>
			</div>
		</div>
		{/* Donation Activity & Top Donors */}
		<div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
			<div className="bg-white rounded-lg shadow p-6">
				<div className="font-semibold mb-2">Donation Activity</div>
				<ul>
					{donationActivity.map((act, idx) => (
						<li key={idx} className="flex items-center gap-2 py-2 border-b last:border-b-0">
							<span className="bg-green-100 text-green-700 px-2 py-1 rounded text-xs font-semibold">${act.amount}.00 {act.type}</span>
							<span className="text-gray-700 font-medium">{act.donor}</span>
							<span className="text-xs text-gray-500">{act.form}</span>
						</li>
					))}
				</ul>
			</div>
			<div className="bg-white rounded-lg shadow p-6">
				<div className="font-semibold mb-2">Top Donors</div>
				<ul>
					{topDonors.map((donor, idx) => (
						<li key={idx} className="flex items-center gap-2 py-2 border-b last:border-b-0">
							<span className="bg-blue-100 text-blue-700 px-2 py-1 rounded text-xs font-semibold">{donor.name}</span>
							<span className="text-gray-700 font-medium">{donor.email}</span>
							<span className="text-xs text-gray-500">{donor.donations} Donation</span>
						</li>
					))}
				</ul>
			</div>
		</div>
       </div>
    </div>
  );
}
