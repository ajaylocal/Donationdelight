"use client";

import { useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

const data = [
  { date: "Sep 02", income: 800, fees: 10 },
  { date: "Sep 03", income: 600, fees: 5 },
  { date: "Sep 04", income: 300, fees: 2 },
  { date: "Sep 06", income: 700, fees: 8 },
  { date: "Sep 08", income: 950, fees: 12 },
  { date: "Sep 10", income: 500, fees: 6 },
  { date: "Sep 12", income: 350, fees: 3 },
  { date: "Sep 14", income: 600, fees: 7 },
  { date: "Sep 16", income: 720, fees: 9 },
  { date: "Sep 18", income: 850, fees: 15 },
];

export default function DonationFeePage() {
  const [filter, setFilter] = useState("This Month");

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold">Fee Income</h2>
        <div className="flex gap-2">
          <Select onValueChange={setFilter} defaultValue={filter}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Filter" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="This Month">This Month</SelectItem>
              <SelectItem value="Last Month">Last Month</SelectItem>
              <SelectItem value="This Year">This Year</SelectItem>
            </SelectContent>
          </Select>
          <Button>Filter</Button>
        </div>
      </div>

      {/* Chart */}
      <Card>
        <CardContent className="h-[400px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis yAxisId="left" orientation="left" stroke="#4CAF50" />
              <YAxis
                yAxisId="right"
                orientation="right"
                stroke="#3f51b5"
                allowDecimals={false}
              />
              <Tooltip />
              <Legend />
              <Line
                yAxisId="left"
                type="monotone"
                dataKey="income"
                stroke="#4CAF50"
                name="Total income for period"
              />
              <Line
                yAxisId="right"
                type="monotone"
                dataKey="fees"
                stroke="#3f51b5"
                name="Total fees collected for period"
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Total income for period</CardTitle>
          </CardHeader>
          <CardContent className="text-2xl font-bold text-green-600">
            $7496.09
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Total donations for period</CardTitle>
          </CardHeader>
          <CardContent className="text-2xl font-bold">63</CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Total fees collected</CardTitle>
          </CardHeader>
          <CardContent className="text-2xl font-bold text-blue-600">
            $68.91
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Percentage of fees</CardTitle>
          </CardHeader>
          <CardContent className="text-2xl font-bold">0.00%</CardContent>
        </Card>
      </div>
    </div>
  );
}
