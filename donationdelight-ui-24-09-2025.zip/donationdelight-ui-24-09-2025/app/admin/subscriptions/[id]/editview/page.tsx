"use client";
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import Link from "next/link";

const mockData = {
	donor: "Jessica Johnson",
	donationFormType: "Fundraising Campaign",
	initialDonationId: "473",
	billingPeriod: "Monthly",
	timesBilled: "4 / Ongoing",
	donationFormId: "",
	gateway: "Test Donation",
	profileId: "sub_6840667f139_1950",
	transactionId: "txn_6840667f1b9_6678",
	dateCreated: "June 1, 2025",
	renewalDate: "October 1, 2025",
	status: "Active",
	subscriptionValue: 1000,
	renewals: [
		{ id: 423, amount: 250, date: "September 1, 2025", status: "Renewal" },
		{ id: 422, amount: 250, date: "August 1, 2025", status: "Renewal" },
		{ id: 421, amount: 250, date: "July 1, 2025", status: "Renewal" },
		{ id: 420, amount: 250, date: "June 1, 2025", status: "Complete" },
	],
	notes: "",
};

export default function EditViewPage() {
	const [profileId, setProfileId] = useState(mockData.profileId);
	const [transactionId, setTransactionId] = useState(mockData.transactionId);
	const [renewalDate, setRenewalDate] = useState(mockData.renewalDate);
	const [status, setStatus] = useState(mockData.status);
	const [notes, setNotes] = useState(mockData.notes);
	const [showRenewalModal, setShowRenewalModal] = useState(false);
	const [renewalAmount, setRenewalAmount] = useState(250);
	const [renewalFormDate, setRenewalFormDate] = useState("");
	const [updateRenewalFormDate, setUpdateRenewalFormDate] = useState(false);
	const [renewalTransactionId, setRenewalTransactionId] = useState("");

	return (
			<div style={{ width: '100%', minHeight: '100vh', background: '#f8fff8', padding: '32px 0' }}>
				<div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 32px' }}>
					<h2 style={{ marginBottom: 24, display: 'flex', alignItems: 'center', fontWeight: 700, color: '#1b5e20', fontSize: 26 }}>
						<span style={{ color: '#43a047', fontSize: 26, marginRight: 10 }}>💚</span>
						Subscription Details - 32 {mockData.donor}
					</h2>
					<div style={{ background: '#fff', borderRadius: 12, boxShadow: '0 2px 12px #e0f2f1', padding: 32, marginBottom: 32 }}>
						<table style={{ width: '100%', marginBottom: 18, fontSize: 16 }}>
							<tbody>
								<tr><td style={{ fontWeight: 600, color: '#388e3c' }}>Donor:</td><td>{mockData.donor}</td></tr>
								<tr><td style={{ fontWeight: 600, color: '#388e3c' }}>Donation Form Type:</td><td>{mockData.donationFormType}</td></tr>
								<tr><td style={{ fontWeight: 600, color: '#388e3c' }}>Initial Donation ID:</td><td>{mockData.initialDonationId}</td></tr>
								<tr><td style={{ fontWeight: 600, color: '#388e3c' }}>Billing Period:</td><td>{mockData.billingPeriod}</td></tr>
								<tr><td style={{ fontWeight: 600, color: '#388e3c' }}>Times Billed:</td><td>{mockData.timesBilled}</td></tr>
								<tr><td style={{ fontWeight: 600, color: '#388e3c' }}>Donation Form ID:</td><td>{mockData.donationFormId}</td></tr>
								<tr><td style={{ fontWeight: 600, color: '#388e3c' }}>Gateway:</td><td>{mockData.gateway}</td></tr>
								<tr>
									<td style={{ fontWeight: 600, color: '#388e3c' }}>Profile ID:</td>
									<td>
										<input value={profileId} onChange={e => setProfileId(e.target.value)} style={{ width: 220, borderRadius: 6, border: '1px solid #b2dfdb', padding: '4px 8px' }} />
										<span style={{ marginLeft: 8, color: '#1976d2', cursor: 'pointer', fontWeight: 500 }}>Edit</span>
									</td>
								</tr>
								<tr>
									<td style={{ fontWeight: 600, color: '#388e3c' }}>Transaction ID:</td>
									<td>
										<input value={transactionId} onChange={e => setTransactionId(e.target.value)} style={{ width: 220, borderRadius: 6, border: '1px solid #b2dfdb', padding: '4px 8px' }} />
										<span style={{ marginLeft: 8, color: '#1976d2', cursor: 'pointer', fontWeight: 500 }}>Edit</span>
									</td>
								</tr>
								<tr><td style={{ fontWeight: 600, color: '#388e3c' }}>Date Created:</td><td>{mockData.dateCreated}</td></tr>
								<tr>
									<td style={{ fontWeight: 600, color: '#388e3c' }}>Renewal Date:</td>
									<td>
										<input value={renewalDate} onChange={e => setRenewalDate(e.target.value)} style={{ width: 180, borderRadius: 6, border: '1px solid #b2dfdb', padding: '4px 8px' }} />
										<span style={{ marginLeft: 8, color: '#1976d2', cursor: 'pointer', fontWeight: 500 }}>Edit</span>
									</td>
								</tr>
								<tr>
									<td style={{ fontWeight: 600, color: '#388e3c' }}>Subscription Status:</td>
									<td>
										<select value={status} onChange={e => setStatus(e.target.value)} style={{ width: 120, borderRadius: 6, border: '1px solid #b2dfdb', padding: '4px 8px' }}>
											<option value="Active">Active</option>
											<option value="Inactive">Inactive</option>
											<option value="Cancelled">Cancelled</option>
										</select>
										<span style={{ marginLeft: 8, color: status === "Active" ? '#43a047' : '#f44336', fontWeight: 700 }}>●</span>
									</td>
								</tr>
							</tbody>
						</table>
						<div style={{ margin: '18px 0', fontWeight: 700, fontSize: 20, color: '#1b5e20' }}>
							$ {mockData.subscriptionValue.toLocaleString()} Subscription Value
						</div>
						<div style={{ display: 'flex', gap: 12, marginBottom: 12 }}>
							<button style={{ background: '#1976d2', color: '#fff', border: 'none', borderRadius: 6, padding: '8px 24px', fontWeight: 600, fontSize: 16, boxShadow: '0 1px 4px #e3f2fd' }}>Sync Subscription</button>
							<button style={{ background: '#388e3c', color: '#fff', border: 'none', borderRadius: 6, padding: '8px 24px', fontWeight: 600, fontSize: 16, boxShadow: '0 1px 4px #c8e6c9' }}>Update Subscription</button>
							<button style={{ background: '#fbc02d', color: '#fff', border: 'none', borderRadius: 6, padding: '8px 24px', fontWeight: 600, fontSize: 16, boxShadow: '0 1px 4px #fffde7' }}>Cancel Subscription</button>
							<button style={{ background: '#e53935', color: '#fff', border: 'none', borderRadius: 6, padding: '8px 24px', fontWeight: 600, fontSize: 16, boxShadow: '0 1px 4px #ffcdd2' }}>Delete Subscription</button>
						</div>
					</div>

					<div style={{ background: '#fff', borderRadius: 12, boxShadow: '0 2px 12px #e0f2f1', padding: 32, marginBottom: 32 }}>
						<div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 }}>
							<b style={{ fontSize: 18, color: '#388e3c' }}>Renewals</b>
							<Button style={{ background: '#1976d2', color: '#fff', border: 'none', borderRadius: 6, padding: '6px 18px', fontWeight: 600, fontSize: 15, boxShadow: '0 1px 4px #e3f2fd' }} onClick={() => setShowRenewalModal(true)}>Add Renewal</Button>
					{/* Renewal Modal */}
					{showRenewalModal && (
						<div style={{ position: 'fixed', inset: 0, zIndex: 50, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(0,0,0,0.3)' }}>
							<div style={{ background: '#fff', borderRadius: 12, boxShadow: '0 2px 12px #e0f2f1', width: '100%', maxWidth: 400, padding: 32, position: 'relative' }}>
								<button
									style={{ position: 'absolute', top: 18, right: 18, color: '#888', fontSize: 22, background: 'none', border: 'none', cursor: 'pointer' }}
									onClick={() => setShowRenewalModal(false)}
									aria-label="Close"
								>
									&times;
								</button>
								<h2 style={{ fontSize: 22, fontWeight: 700, marginBottom: 24 }}>Renewal donation</h2>
								<form style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
									<div>
										<label style={{ display: 'block', fontWeight: 500, marginBottom: 6 }}>Amount</label>
										<input
											type="number"
											style={{ width: '100%', borderRadius: 6, border: '1px solid #b2dfdb', padding: '8px 12px' }}
											value={renewalAmount}
											onChange={e => setRenewalAmount(Number(e.target.value))}
										/>
									</div>
									<div>
										<label style={{ display: 'block', fontWeight: 500, marginBottom: 6 }}>Date</label>
										<input
											type="date"
											style={{ width: '100%', borderRadius: 6, border: '1px solid #b2dfdb', padding: '8px 12px' }}
											value={renewalFormDate}
											onChange={e => setRenewalFormDate(e.target.value)}
										/>
									</div>
									<div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
										<input
											type="checkbox"
											checked={updateRenewalFormDate}
											onChange={e => setUpdateRenewalFormDate(e.target.checked)}
										/>
										<label style={{ fontWeight: 500 }}>Update renewal date</label>
									</div>
									<div>
										<label style={{ display: 'block', fontWeight: 500, marginBottom: 6 }}>Transaction ID <span style={{ color: '#888', fontWeight: 400 }}>(optional)</span></label>
										<input
											type="text"
											style={{ width: '100%', borderRadius: 6, border: '1px solid #b2dfdb', padding: '8px 12px' }}
											value={renewalTransactionId}
											onChange={e => setRenewalTransactionId(e.target.value)}
										/>
									</div>
									<Button style={{ width: '100%', marginTop: 12, background: '#1976d2', color: '#fff', borderRadius: 6, fontWeight: 600, fontSize: 16 }}>Add renewal</Button>
									<div style={{ border: '1px solid #90caf9', borderRadius: 6, background: '#e3f2fd', color: '#1976d2', padding: '10px 14px', fontSize: 15, marginTop: 8, display: 'flex', alignItems: 'center', gap: 8 }}>
										<svg width="18" height="18" fill="none" viewBox="0 0 24 24"><rect width="24" height="24" rx="12" fill="#E3F2FD"/><path d="M12 8v4l3 3" stroke="#1976d2" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
										<span>Please note that this will not charge the donor nor create the renewal at the gateway.</span>
									</div>
								</form>
							</div>
						</div>
					)}
						</div>
						<table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 15 }}>
							<thead>
								<tr style={{ background: '#e8f5e9' }}>
									<th style={{ padding: 10, border: '1px solid #c8e6c9', color: '#388e3c', fontWeight: 700 }}>ID</th>
									<th style={{ padding: 10, border: '1px solid #c8e6c9', color: '#388e3c', fontWeight: 700 }}>Amount</th>
									<th style={{ padding: 10, border: '1px solid #c8e6c9', color: '#388e3c', fontWeight: 700 }}>Date</th>
									<th style={{ padding: 10, border: '1px solid #c8e6c9', color: '#388e3c', fontWeight: 700 }}>Status</th>
									<th style={{ padding: 10, border: '1px solid #c8e6c9', color: '#388e3c', fontWeight: 700 }}>Actions</th>
								</tr>
							</thead>
							<tbody>
								{mockData.renewals.map(r => (
									<tr key={r.id} style={{ background: r.status === 'Complete' ? '#fffde7' : '#fff' }}>
										<td style={{ padding: 10, border: '1px solid #c8e6c9' }}>{r.id}</td>
										<td style={{ padding: 10, border: '1px solid #c8e6c9' }}>$ {r.amount.toFixed(2)}</td>
										<td style={{ padding: 10, border: '1px solid #c8e6c9' }}>{r.date}</td>
										<td style={{ padding: 10, border: '1px solid #c8e6c9' }}>{r.status}</td>
										<td style={{ padding: 10, border: '1px solid #c8e6c9' }}>
																<Link
																	href={`/admin/subscriptions/32/renewals/${r.id}/viewdetails`}
																	style={{ textDecoration: 'none' }}
																	passHref
																>
																	<button style={{ background: '#1976d2', color: '#fff', border: 'none', borderRadius: 6, padding: '4px 14px', fontWeight: 600, fontSize: 14, boxShadow: '0 1px 4px #e3f2fd' }}>
																		View Details
																	</button>
																</Link>
															</td>
									</tr>
								))}
							</tbody>
						</table>
					</div>

					<div style={{ background: '#fff', borderRadius: 12, boxShadow: '0 2px 12px #e0f2f1', padding: 32 }}>
						<b style={{ fontSize: 18, color: '#388e3c' }}>Subscription Notes</b>
						<div style={{ margin: '16px 0' }}>
							<textarea value={notes} onChange={e => setNotes(e.target.value)} rows={4} style={{ width: '100%', borderRadius: 8, border: '1px solid #b2dfdb', padding: 10, fontSize: 15, background: '#f8fff8' }} placeholder="No subscription notes." />
						</div>
						<button style={{ background: '#1976d2', color: '#fff', border: 'none', borderRadius: 6, padding: '6px 18px', fontWeight: 600, fontSize: 15, boxShadow: '0 1px 4px #e3f2fd' }}>Add Note</button>
					</div>
					{/* <div style={{ fontSize: 14, color: '#888', marginTop: 32, textAlign: 'center' }}>
						If you like DonationDelight please leave us a ★★★★★ rating. It takes a minute and helps a lot. Thanks in advance!
					</div> */}
				</div>
			</div>
		);
}
