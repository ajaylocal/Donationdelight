"use client"

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

// Sample data (replace with API results)
const gateways = [
  { gateway: "Offline Donation", complete: 0, failed: 0, total: 0, donated: 0 },
  { gateway: "PayPal Donations", complete: 0, failed: 0, total: 0, donated: 0 },
  { gateway: "PayPal Standard", complete: 0, failed: 0, total: 0, donated: 0 },
  { gateway: "Stripe - BECS Direct Debit", complete: 0, failed: 0, total: 0, donated: 0 },
  { gateway: "Stripe - Checkout", complete: 0, failed: 0, total: 0, donated: 0 },
  { gateway: "Stripe - Credit Card", complete: 0, failed: 0, total: 0, donated: 0 },
  { gateway: "Stripe - Payment Element", complete: 0, failed: 0, total: 0, donated: 0 },
  { gateway: "Stripe - SEPA Direct Debit", complete: 0, failed: 0, total: 0, donated: 0 },
  { gateway: "Test Donation", complete: 656, failed: 0, total: 656, donated: 75013 },
]

export default function DonationMethods() {
  return (
    <div className="p-6 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Donation Methods Report</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Gateway</TableHead>
                <TableHead>Complete Payments</TableHead>
                <TableHead>Pending / Failed Payments</TableHead>
                <TableHead>Total Payments</TableHead>
                <TableHead className="text-right">Total Donated</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {gateways.map((g, i) => (
                <TableRow key={i}>
                  <TableCell>{g.gateway}</TableCell>
                  <TableCell>{g.complete}</TableCell>
                  <TableCell>{g.failed}</TableCell>
                  <TableCell>{g.total}</TableCell>
                  <TableCell className="text-right">
                    {g.donated > 0
                      ? `$${g.donated.toLocaleString()}`
                      : "$0"}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
