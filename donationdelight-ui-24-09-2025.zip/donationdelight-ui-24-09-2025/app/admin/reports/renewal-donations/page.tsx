"use client";

import { useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

const data = [
  { date: "Sep 02", income: 200, renewals: 1 },
  { date: "Sep 03", income: 0, renewals: 0 },
  { date: "Sep 04", income: 0, renewals: 0 },
  { date: "Sep 08", income: 60, renewals: 1 },
  { date: "Sep 12", income: 0, renewals: 0 },
  { date: "Sep 20", income: 0, renewals: 0 },
  { date: "Sep 30", income: 0, renewals: 0 },
];

export default function DonationRenewalPage() {
  const [filter, setFilter] = useState("This Month");

  return (
    <div className="p-6 space-y-6">
      {/* Header with filter */}
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold">Donation Renewals</h2>
        <div className="flex gap-2">
          <Select onValueChange={setFilter} defaultValue={filter}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Filter" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="This Month">This Month</SelectItem>
              <SelectItem value="Last Month">Last Month</SelectItem>
              <SelectItem value="This Year">This Year</SelectItem>
            </SelectContent>
          </Select>
          <Button>Filter</Button>
        </div>
      </div>

      {/* Chart */}
      <Card>
        <CardContent className="h-[400px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis yAxisId="left" orientation="left" stroke="#4CAF50" />
              <YAxis yAxisId="right" orientation="right" stroke="#3f51b5" />
              <Tooltip />
              <Legend />
              <Line
                yAxisId="left"
                type="monotone"
                dataKey="income"
                stroke="#4CAF50"
                name="Income"
              />
              <Line
                yAxisId="right"
                type="monotone"
                dataKey="renewals"
                stroke="#3f51b5"
                name="Renewals"
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Summary */}
      <div className="grid md:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Total earnings for period shown</CardTitle>
          </CardHeader>
          <CardContent className="text-2xl font-bold text-green-600">
            $260.00
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Total renewal donations</CardTitle>
          </CardHeader>
          <CardContent className="text-2xl font-bold text-blue-600">
            2
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
