'use client'
import { useState } from "react";
import Link from "next/link";

const mockUser = { id: 1, name: "Ajay Local", email: "ajay@donationdelight.com", role: "Admin", phone: "", password: "" };

export default function EditUserPage() {
  const [name, setName] = useState(mockUser.name);
  const [email, setEmail] = useState(mockUser.email);
  const [role, setRole] = useState(mockUser.role);
  const [password, setPassword] = useState("");
  const [phone, setPhone] = useState(mockUser.phone);
  const [showPassword, setShowPassword] = useState(false);
  function generatePassword(length = 10) {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*";
    let pass = "";
    for (let i = 0; i < length; i++) {
      pass += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setPassword(pass);
  }

  return (
    <div className="max-w-8xl mx-auto p-8 bg-white rounded shadow">
      <h1 className="text-2xl font-bold text-green-700 mb-6">Edit User</h1>
      <form className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1">Name <span className="text-red-500">*</span></label>
          <input className="w-full border rounded px-2 py-2" value={name} onChange={e => setName(e.target.value)} placeholder="Enter name" required />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Email <span className="text-red-500">*</span></label>
          <input className="w-full border rounded px-2 py-2" value={email} onChange={e => setEmail(e.target.value)} placeholder="Enter email" type="email" required />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Role <span className="text-red-500">*</span></label>
          <select className="w-full border rounded px-2 py-2" value={role} onChange={e => setRole(e.target.value)} required>
            <option value="Admin">Admin</option>
            <option value="Manager">Manager</option>
            <option value="Staff">Staff</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Password <span className="text-red-500">*</span></label>
          <div className="flex gap-2 items-center">
            <input
              className="w-full border rounded px-2 py-2"
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="Enter password"
              type={showPassword ? "text" : "password"}
              required
            />
            <button
              type="button"
              className="px-3 py-2 bg-blue-600 text-white rounded text-sm font-semibold"
              onClick={e => { e.preventDefault(); generatePassword(); }}
            >
              Generate
            </button>
            <button
              type="button"
              className="px-3 py-2 bg-gray-300 text-gray-700 rounded text-sm font-semibold"
              onClick={e => { e.preventDefault(); setShowPassword(v => !v); }}
            >
              {showPassword ? "Hide" : "Show"}
            </button>
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Phone Number</label>
          <input className="w-full border rounded px-2 py-2" value={phone} onChange={e => setPhone(e.target.value)} placeholder="Enter phone number" type="tel" />
        </div>
        <div className="flex gap-4 mt-6">
          <Link href="/admin/users">
            <button type="button" className="px-6 py-2 bg-gray-300 text-gray-700 rounded font-semibold">Cancel</button>
          </Link>
          <button type="submit" className="px-6 py-2 bg-green-600 text-white rounded font-semibold">Save Changes</button>
        </div>
      </form>
    </div>
  );
}
