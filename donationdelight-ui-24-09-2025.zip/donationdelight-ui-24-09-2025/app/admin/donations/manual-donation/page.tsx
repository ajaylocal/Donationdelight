'use client'
import React, { useState } from "react";
import { Dialog, DialogTrigger, DialogContent } from "@/components/ui/dialog";

export default function ManualDonationPage() {
    // Example data, replace with real API data as needed
    const campaigns = [
      { id: "c1", name: "Climate Action" },
      { id: "c2", name: "Education Fund" },
      { id: "c3", name: "Health Drive" },
    ];
    const forms = [
      { id: "f1", name: "Climate Donation Form", campaignId: "c1" },
      { id: "f2", name: "Climate Monthly Form", campaignId: "c1" },
      { id: "f3", name: "Education General Form", campaignId: "c2" },
      { id: "f4", name: "Health Emergency Form", campaignId: "c3" },
    ];

    const [selectedCampaign, setSelectedCampaign] = useState<string>("");
    const filteredForms = selectedCampaign
      ? forms.filter(f => f.campaignId === selectedCampaign)
      : forms;
    const [selectedForm, setSelectedForm] = useState<string>("");

    const [paymentMethod, setPaymentMethod] = useState<string>("Case Payment");
    const [checkNumber, setCheckNumber] = useState("");
    const [paymentNote, setPaymentNote] = useState("");

    return (
      <div className="max-w-full mx-auto p-6 bg-white rounded shadow">
        <h1 className="text-2xl font-bold mb-6">New Donation</h1>
        <form className="space-y-8">
          {/* Donation Form Section */}
          <div className="border rounded p-4 mb-6">
            <h2 className="text-lg font-semibold mb-4">Donation </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">Donation Campaigns</label>
                <select
                  className="w-full border rounded px-2 py-3"
                  value={selectedCampaign}
                  onChange={e => {
                    setSelectedCampaign(e.target.value);
                    setSelectedForm("");
                  }}
                >
                  <option value="">All Campaigns</option>
                  {campaigns.map(c => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Donation Form</label>
                <select
                  className="w-full border rounded px-2 py-3"
                  value={selectedForm}
                  onChange={e => setSelectedForm(e.target.value)}
                  disabled={filteredForms.length === 0}
                >
                  <option value="">All Forms</option>
                  {filteredForms.map(f => (
                    <option key={f.id} value={f.id}>{f.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Donation Level</label>
                <input className="w-full border rounded px-2 py-3" placeholder="n/a" disabled />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Donation Amount ($)</label>
                <input type="number" className="w-full border rounded px-2 py-3" placeholder="0.00" />
              </div>
            </div>
          </div>

          {/* Donor Section */}
          <div className="border rounded p-4 mb-6">
            <h2 className="text-lg font-semibold mb-4">Donor</h2>
            <div className="flex gap-4 items-center">
              <Dialog>
                <DialogTrigger asChild>
                  <button type="button" className="px-4 py-2 bg-blue-600 text-white rounded">Add Donor</button>
                </DialogTrigger>
                <DialogContent>
                  <h2 className="text-xl font-bold mb-2">Add Donor</h2>
                  <div className="flex items-center gap-2 mb-4">
                    <input
                      type="text"
                      placeholder="Enter keyword to search donor"
                      className="flex-1 border rounded px-2 py-2"
                    />
                    <button type="button" className="px-4 py-2 border rounded text-red-600 flex items-center gap-1">
                      Clear <span className="ml-1">&#10006;</span>
                    </button>
                  </div>
                  <div className="mb-4">
                    <div className="flex">
                      <button type="button" className="flex-1 bg-gray-200 text-black font-semibold py-2 rounded-l">Donor Info</button>
                      <button type="button" className="flex-1 bg-gray-100 text-gray-500 font-semibold py-2 rounded-r" disabled>Order History</button>
                    </div>
                  </div>
                  <form className="space-y-3">
                    <input className="w-full border rounded px-2 py-2" placeholder="Name" defaultValue="John Doe" />
                    <input className="w-full border rounded px-2 py-2" placeholder="Enter email address" type="email" />
                    <input className="w-full border rounded px-2 py-2" placeholder="Enter phone number" type="tel" required />
                    <input className="w-full border rounded px-2 py-2" placeholder="Enter address" />
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                      <input className="border rounded px-2 py-2" placeholder="Enter city" />
                      <input className="border rounded px-2 py-2" placeholder="Enter state" />
                      <input className="border rounded px-2 py-2" placeholder="Enter zip code" />
                    </div>
                    <textarea className="w-full border rounded px-2 py-2" placeholder="Enter note" />
                    <div className="flex gap-4 mt-4">
                      <button type="button" className="flex-1 px-6 py-2 bg-red-500 text-white rounded font-semibold flex items-center justify-center gap-2">
                        &#10006; Cancel
                      </button>
                      <button type="submit" className="flex-1 px-6 py-2 bg-green-400 text-white rounded font-semibold flex items-center justify-center gap-2">
                        &#10003; Confirm
                      </button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          {/* Peer-to-Peer Section */}
          {/* <div className="border rounded p-4 mb-6 grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Peer-to-Peer Campaign</label>
              <select className="w-full border rounded px-2 py-3">
                <option>Unassigned</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Peer-to-Peer Team</label>
              <select className="w-full border rounded px-2 py-3">
                <option>Unassigned</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Peer-to-Peer Fundraiser</label>
              <select className="w-full border rounded px-2 py-3">
                <option>Unassigned</option>
              </select>
            </div>
          </div> */}

          {/* Status, Payment, Date Section */}
          <div className="border rounded p-4 mb-6 grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Donation Status</label>
              <select className="w-full border rounded px-2 py-3">
                <option>Complete</option>
                <option>Processing</option>
                <option>Pending</option>
                <option>Refunded</option>
                <option>Abandoned</option>
                <option>Renewal</option>
                <option>Revoked</option>
                <option>Failed</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Payment Method</label>
              <select
                className="w-full border rounded px-2 py-3"
                value={paymentMethod}
                onChange={e => setPaymentMethod(e.target.value)}
              >
                 <option>Case Payment</option>
                 <option>Check Payment</option>
                 <option>Othere</option>
              </select>
              {paymentMethod === "Check Payment" && (
                <div className="mt-2">
                  <label className="block text-sm font-medium mb-1">Check Number</label>
                  <input
                    className="w-full border rounded px-2 py-2"
                    placeholder="Enter check number"
                    value={checkNumber}
                    onChange={e => setCheckNumber(e.target.value)}
                  />
                </div>
              )}
              {paymentMethod === "Othere" && (
                <div className="mt-2">
                  <label className="block text-sm font-medium mb-1">Payment Note</label>
                  <input
                    className="w-full border rounded px-2 py-2"
                    placeholder="Enter payment note"
                    value={paymentNote}
                    onChange={e => setPaymentNote(e.target.value)}
                  />
                </div>
              )}
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Donation Date</label>
              <input type="datetime-local" className="w-full border rounded px-2 py-3" />
            </div>
          </div>

          {/* Billing Address Section */}
          {/* <div className="border rounded p-4 mb-6 grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Country</label>
              <select className="w-full border rounded px-2 py-3 mb-2">
                <option>United States</option>
              </select>
              <label className="block text-sm font-medium mb-1">Address 2</label>
              <input className="w-full border rounded px-2 py-3 mb-2" placeholder="Address line 2" />
              <label className="block text-sm font-medium mb-1">State</label>
              <select className="w-full border rounded px-2 py-3">
                <option>Rhode Island</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Address 1</label>
              <input className="w-full border rounded px-2 py-3 mb-2" placeholder="Address line 1" />
              <label className="block text-sm font-medium mb-1">City</label>
              <input className="w-full border rounded px-2 py-3 mb-2" placeholder="City" />
              <label className="block text-sm font-medium mb-1">Zip / Postal Code</label>
              <input className="w-full border rounded px-2 py-3" placeholder="Zip / Postal Code" />
            </div>
          </div> */}

          {/* Receipt & Notification Section */}
          <div className="border rounded p-4 mb-6 grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-center gap-2">
              <input type="checkbox" id="send-receipt" className="border rounded" />
              <label htmlFor="send-receipt" className="text-sm">Send donor receipt</label>
            </div>
            <div className="flex items-center gap-2">
              <input type="checkbox" id="send-admin" className="border rounded" />
              <label htmlFor="send-admin" className="text-sm">Send admin notification</label>
            </div>
          </div>

          {/* Note Section */}
          {/* <div className="border rounded p-4 mb-6">
            <label className="block text-sm font-medium mb-1">Note</label>
            <textarea className="w-full border rounded px-2 py-1 min-h-[80px]" placeholder="Add an optional note to this donation." />
          </div> */}

          <button type="submit" className="px-6 py-2 bg-green-600 text-white rounded font-semibold">Create Donation</button>
        </form>
      </div>
    )
}