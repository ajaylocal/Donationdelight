"use client";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const forms = [
  {
    form: "Student Meal Program: $10",
    donations: 40,
    revenue: "$4,965.00",
    avgDonations: 13,
    avgRevenue: "$1,655.00",
  },
  {
    form: "Student Meal Fund: General Fund",
    donations: 0,
    revenue: "$0",
    avgDonations: 0,
    avgRevenue: "$0",
  },
  {
    form: "Local Business Recovery",
    donations: 50,
    revenue: "$5,755.00",
    avgDonations: 17,
    avgRevenue: "$1,918.33",
  },
  {
    form: "Help Fund Our New Community Library",
    donations: 145,
    revenue: "$16,400.00",
    avgDonations: 145,
    avgRevenue: "$16,400.00",
  },
  {
    form: "Fundraising Campaign",
    donations: 82,
    revenue: "$7,913.00",
    avgDonations: 27,
    avgRevenue: "$2,637.67",
  },
  {
    form: "Anniversary",
    donations: 15,
    revenue: "$1,135.00",
    avgDonations: 5,
    avgRevenue: "$378.33",
  },
];

export default function DonationFormPage() {
  return (
    <div className="p-6 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Donation Forms</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Form</TableHead>
                  <TableHead>Donations</TableHead>
                  <TableHead>Revenue</TableHead>
                  <TableHead>Monthly Avg Donations</TableHead>
                  <TableHead>Monthly Avg Revenue</TableHead>
                  <TableHead>Detailed Report</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {forms.map((item, i) => (
                  <TableRow key={i}>
                    <TableCell>{item.form}</TableCell>
                    <TableCell>{item.donations}</TableCell>
                    <TableCell>{item.revenue}</TableCell>
                    <TableCell>{item.avgDonations}</TableCell>
                    <TableCell>{item.avgRevenue}</TableCell>
                    <TableCell>
                      <Button variant="outline" size="sm">
                        View Detailed Report
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
