"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { RefreshCw } from "lucide-react"
import {
  ResponsiveContainer,
  LineChart,
  Line,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
} from "recharts"

// Sample data (replace with API data)
const data = [
  { date: "Sep 02", revenue: 720, donations: 5 },
  { date: "Sep 03", revenue: 900, donations: 6 },
  { date: "Sep 04", revenue: 650, donations: 4 },
  { date: "Sep 05", revenue: 200, donations: 2 },
  { date: "Sep 06", revenue: 780, donations: 5 },
  { date: "Sep 07", revenue: 1000, donations: 7 },
]

export default function DonationRevenue() {
  const [filter, setFilter] = useState("this_month")

  return (
    <div className="space-y-6 p-6">
      {/* Filter Row */}
      <div className="flex items-center gap-3">
        <Select defaultValue={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Select Period" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="this_month">This Month</SelectItem>
            <SelectItem value="last_month">Last Month</SelectItem>
            <SelectItem value="custom">Custom Range</SelectItem>
          </SelectContent>
        </Select>
        <Button variant="outline">Filter</Button>
      </div>

      {/* Chart */}
      <Card>
        <CardContent className="pt-6">
          <ResponsiveContainer width="100%" height={350}>
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis yAxisId="left" />
              <YAxis yAxisId="right" orientation="right" />
              <Tooltip />
              <Legend />
              <Line
                yAxisId="left"
                type="monotone"
                dataKey="revenue"
                stroke="#22c55e"
                strokeWidth={2}
                dot={{ r: 4 }}
                name="Revenue"
              />
              <Line
                yAxisId="right"
                type="monotone"
                dataKey="donations"
                stroke="#3b82f6"
                strokeWidth={2}
                dot={{ r: 4 }}
                name="Donations"
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Stats Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Total revenue for period</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-green-600">$7,915.00</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Total donations for period</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-blue-600">69</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Estimated monthly revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-green-600">$9,893.75</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Estimated monthly donations</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-blue-600">86</p>
          </CardContent>
        </Card>
      </div>

      {/* Refresh button */}
      <div className="flex justify-end">
        <Button variant="outline" size="sm">
          <RefreshCw className="mr-2 h-4 w-4" />
          Refresh Report Data
        </Button>
      </div>
    </div>
  )
}
