'use client'
import Link from "next/link";
const mockUsers = [
  { id: 1, name: "Ajay Local", email: "ajay@donationdelight.com", role: "Admin" },
  { id: 2, name: "Jessica Johnson", email: "jessica@donationdelight.com", role: "Manager" },
  { id: 3, name: "Richard Lee", email: "richard@donationdelight.com", role: "Staff" },
];

export default function UserListPage() {
  return (
    <div className="max-w-12xl mx-auto p-8 bg-white rounded shadow">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-green-700">Users</h1>
        <Link href="/admin/users/create">
          <button className="px-4 py-2 bg-green-600 text-white rounded font-semibold">Add User</button>
        </Link>
      </div>
      <table className="w-full border rounded overflow-hidden">
        <thead className="bg-green-50">
          <tr>
            <th className="py-3 px-4 text-left text-green-700 font-semibold">Name</th>
            <th className="py-3 px-4 text-left text-green-700 font-semibold">Email</th>
            <th className="py-3 px-4 text-left text-green-700 font-semibold">Role</th>
            <th className="py-3 px-4 text-left text-green-700 font-semibold">Actions</th>
          </tr>
        </thead>
        <tbody>
          {mockUsers.map(user => (
            <tr key={user.id} className="border-b last:border-b-0">
              <td className="py-2 px-4">{user.name}</td>
              <td className="py-2 px-4">{user.email}</td>
              <td className="py-2 px-4">{user.role}</td>
              <td className="py-2 px-4">
                <Link href={`/admin/users/${user.id}/edit`}>
                  <button className="px-3 py-1 bg-blue-600 text-white rounded text-sm font-semibold mr-2">Edit</button>
                </Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}